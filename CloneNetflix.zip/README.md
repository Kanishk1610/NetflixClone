# Netflix

Designed a Netflix home page using HTML, CSS and JavaScript.
Click here to See Live:
https://codeharshly.github.io/CloneNetflix
